#include "stdafx.h"
#include "class1.h"

void CCobject::init(float x, float y, float z, float size, float r, float g, float b, float a)
{
	m_x = x;
	m_y = y;
	m_z = z;
	m_size = size;
	m_r = r;
	m_g = g;
	m_b = b;
	m_a = a;
}